#!/bin/sh

PRODUCT_NAME="exemONE"
MODULE_NAME="exem-java-agent"
VERSION="3.0.24.1"

echo ${PRODUCT_NAME} ${MODULE_NAME} ver ${VERSION}